# Strings







*String operations.*



