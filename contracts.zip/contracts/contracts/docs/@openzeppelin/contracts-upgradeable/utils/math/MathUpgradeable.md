# MathUpgradeable







*Standard math utilities missing in the Solidity language.*



