export interface IRole {
	value: string;
	label: string;
}
