import { Box } from '@chakra-ui/react';

const Dashboard = () => {
	return <Box data-testid='dashboard_container'>Dashboard</Box>;
};

export default Dashboard;
