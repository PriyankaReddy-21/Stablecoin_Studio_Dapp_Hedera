import { VStack } from '@chakra-ui/react';
import type { CreateRequest } from '@hashgraph/stablecoin-npm-sdk';
import type { Control, FieldValues } from 'react-hook-form';
import { useWatch } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import InputController from '../../../components/Form/InputController';
import { SelectController } from '../../../components/Form/SelectController';
import { propertyNotFound } from '../../../constant';
import { handleRequestValidation } from '../../../utils/validationsHelper';

export const OTHER_KEY_VALUE = 3;

interface KeySelectorProps {
	control: Control<FieldValues>;
	name: string;
	label: string;
	request: CreateRequest;
}

const KeySelector = ({ control, name, label, request }: KeySelectorProps) => {
	const { t } = useTranslation(['global', 'stableCoinCreation']);

	const optionsKeys = [
		{
			value: 1,
			label: t('stableCoinCreation:managementPermissions.currentUserKey'),
		},
		{
			value: 2,
			label: t('stableCoinCreation:managementPermissions.theSmartContract'),
		},
		{
			value: 3,
			label: t('stableCoinCreation:managementPermissions.otherKey'),
		},
		{
			value: 4,
			label: t('stableCoinCreation:managementPermissions.none'),
		},
	];

	const selectorStyle = {
		wrapper: {
			border: '1px',
			borderColor: 'brand.black',
			borderRadius: '8px',
			height: 'min',
		},
		menuList: {
			maxH: '220px',
			overflowY: 'auto',
			bg: 'brand.white',
			boxShadow: 'down-black',
			p: 2,
			zIndex: 99,
		},
		valueSelected: {
			fontSize: '14px',
			fontWeight: '500',
		},
	};

	const isOtherKeyOptionSelected = useWatch({
		control,
		name,
	});

	const availableOptions = () => {
		if (name === 'feeScheduleKey')
			return optionsKeys.filter((option) => ![2, 4].includes(option.value));
		if (name === 'kycKey') return optionsKeys.filter((option) => option.value !== 4);

		return optionsKeys;
	};

	return (
		<VStack>
			<SelectController
				control={control}
				name={name}
				options={availableOptions()}
				defaultValue={name === 'feeScheduleKey' ? '0' : '1'}
				label={label}
				overrideStyles={selectorStyle}
				addonLeft={true}
				variant='unstyled'
			/>
			{isOtherKeyOptionSelected?.value === OTHER_KEY_VALUE && (
				<InputController
					rules={{
						required: t(`global:validations.required`) ?? propertyNotFound,
						validate: {
							validation: (value: string) => {
								// @ts-ignore
								request[name] = value;
								// @ts-ignore
								const res = handleRequestValidation(request.validate(name));
								return res;
							},
						},
					}}
					isRequired
					control={control}
					name={name + 'Other'}
					placeholder={
						t('stableCoinCreation:managementPermissions.introduce', {
							name: label,
						}) ?? propertyNotFound
					}
				/>
			)}
		</VStack>
	);
};

export default KeySelector;
