export const FormLabel = {
	baseStyle: {
		fontSize: '14px',
		color: 'brand.black',
	},
};
