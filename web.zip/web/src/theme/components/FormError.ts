export const FormError = {
	baseStyle: {
		text: {
			color: 'brand.red',
		},
	},
};
