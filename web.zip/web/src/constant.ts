export const propertyNotFound: string = 'propertyNotFound';
