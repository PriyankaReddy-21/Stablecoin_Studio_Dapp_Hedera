export default class Service {
  constructor(name?: string) {
    name;
  }
}
