export default class BaseEntity {}
