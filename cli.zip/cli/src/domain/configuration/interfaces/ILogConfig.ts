export interface ILogConfig {
  level: string;
  path: string;
}
