export interface IPrivateKey {
  key: string;
  type: string;
}
