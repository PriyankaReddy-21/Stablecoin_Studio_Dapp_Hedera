export interface IFactoryConfig {
  id: string;
  network: string;
}
