export interface IHederaTokenManagerConfig {
  id: string;
  network: string;
}
