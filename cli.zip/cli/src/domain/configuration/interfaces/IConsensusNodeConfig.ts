export interface IConsensusNodeConfig {
  url: string;
  nodeId: string;
}
