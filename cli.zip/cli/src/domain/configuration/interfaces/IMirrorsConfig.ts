export interface IMirrorsConfig {
  name: string;
  network: string;
  baseUrl: string;
  apiKey?: string;
  headerName?: string;
  selected: boolean;
}
