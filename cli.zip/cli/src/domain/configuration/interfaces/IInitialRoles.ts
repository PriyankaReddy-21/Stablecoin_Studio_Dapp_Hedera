export interface IInitialRoles {
  burnRoleAccount: string;
  wipeRoleAccount: string;
  rescueRoleAccount: string;
  pauseRoleAccount: string;
  freezeRoleAccount: string;
  deleteRoleAccount: string;
  kycRoleAccount: string;
  cashInRoleAccount: string;
  cashInRoleAllowance: string;
}
