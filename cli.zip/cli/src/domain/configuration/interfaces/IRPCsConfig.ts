export interface IRPCsConfig {
  name: string;
  network: string;
  baseUrl: string;
  apiKey?: string;
  headerName?: string;
  selected: boolean;
}
