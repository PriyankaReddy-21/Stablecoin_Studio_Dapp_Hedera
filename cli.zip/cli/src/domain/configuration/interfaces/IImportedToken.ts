export interface IImportedToken {
  id: string;
  symbol: string;
}
