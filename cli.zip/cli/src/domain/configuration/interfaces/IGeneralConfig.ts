export interface IGeneralConfig {
  configPath?: string;
  network?: string;
}
